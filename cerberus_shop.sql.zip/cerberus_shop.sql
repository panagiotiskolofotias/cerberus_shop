-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 06 Νοε 2024 στις 20:26:05
-- Έκδοση διακομιστή: 10.4.28-MariaDB
-- Έκδοση PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `cerberus_shop`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `advertisements`
--

CREATE TABLE `advertisements` (
  `id` int(11) NOT NULL,
  `photo_name` varchar(255) NOT NULL,
  `photo_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `advertisements`
--

INSERT INTO `advertisements` (`id`, `photo_name`, `photo_path`) VALUES
(1, 'msi.png', 'images/msi.png'),
(2, 'images/asus.jpg', 'images/asus.jpg'),
(8, 'Spring-Sale-kv.jpg', 'images/Spring-Sale-kv.jpg');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`) VALUES
(1, 'NOKIA'),
(2, 'AMD'),
(3, 'INTEL');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `icons` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `icons`) VALUES
(1, 'Υπολογιστές & Laptops', '<i class=\"lni lni-laptop\"></i>'),
(2, 'Gaming', '<i class=\"lni lni-game\"></i>'),
(3, 'Τηλεφωνία & Tablets', '<i class=\"lni lni-mobile\"></i>'),
(4, 'Εικόνα & Ήχος', '<i class=\"lni lni-image\"></i>'),
(5, 'Οθόνες Υπολογιστών', '<i class=\"lni lni-display-alt\"></i>'),
(6, 'Εκτυπωτές & Αναλώσιμα', '<i class=\"lni lni-printer\"></i>'),
(7, 'Hardware & Αναβάθμιση', '<i class=\"lni lni-briefcase-alt\"></i>'),
(8, 'Οργάνωση γραφείου', '<i class=\"lni lni-paperclip\"></i>'),
(9, 'Δικτυακά servers', '<i class=\"lni lni-database\"></i>'),
(10, 'Είδη σπιτιού', '<i class=\"lni lni-home\"></i>'),
(11, 'Εργαλεία', '<i class=\"lni lni-construction-hammer\"></i>');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `order_status` enum('Pending','Completed') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `orders`
--

INSERT INTO `orders` (`order_id`, `customer_name`, `customer_email`, `total_amount`, `order_date`, `order_status`) VALUES
(6, 'admin', 'admin@gmail.com', 3527.00, '2024-11-06 14:51:51', 'Pending'),
(7, 'admin', 'admin@gmail.com', 1172.00, '2024-11-06 14:52:22', 'Completed');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `product_id`, `product_name`, `quantity`, `price`, `total`) VALUES
(9, 6, 43, 'HP Pro 290 G9 Desktop PC', 1, 581.00, 581.00),
(10, 6, 25, 'Assassin Creed Odyssey', 1, 28.00, 28.00),
(11, 6, 14, 'Samsung Odyssey Neo G9', 1, 2918.00, 2918.00),
(12, 7, 32, 'Microsoft Xbox Series X 1TB', 1, 528.00, 528.00),
(13, 7, 41, 'LG Smart Τηλεόραση 43\" 4K UHD LED 43UR78006L HDR (2023)', 1, 345.00, 345.00),
(14, 7, 34, 'Corsair T3 Rush Fabric (2023)', 1, 299.00, 299.00);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subcategory1_id` int(11) DEFAULT NULL,
  `subcategory2_id` int(11) DEFAULT NULL,
  `Images` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `category_id`, `price`, `subcategory1_id`, `subcategory2_id`, `Images`) VALUES
(7, 'AMD Ryzen 5 7600X', 'AMD Ryzen 5 7600X 4.7GHz Επεξεργαστής 6 Πυρήνων για Socket AM5 σε Κουτί', 7, 218.00, 31, NULL, 'images/AMD_Ryzen_5_9600X.jpeg'),
(8, 'Intel Core i3-12100F', 'Intel Core i3-12100F 3.3GHz Επεξεργαστής 4 Πυρήνων για Socket 1700 σε Κουτί με Ψύκτρα', 7, 117.00, 31, NULL, 'images/Intel Core i3-12100F.jpeg'),
(9, 'AMD Ryzen 7 5700G', 'AMD Ryzen 7 5700G 3.8GHz Επεξεργαστής 8 Πυρήνων για Socket AM4 σε Κουτί', 7, 202.00, 31, NULL, 'images/AMD Ryzen 7 5700G 3.8GHz.jpeg'),
(10, 'AMD Ryzen 5 3600', 'AMD Ryzen 5 3600 3.6GHz Επεξεργαστής 6 Πυρήνων για Socket AM4 σε Κουτί με Ψύκτρα', 7, 109.00, 31, NULL, 'images/AMD Ryzen 5 3600.jpeg'),
(11, 'HP EliteBook 630 G9', 'HP EliteBook 630 G9 13.3', 1, 1085.00, 2, 5, 'images/HP EliteBook 630 G9.jpeg'),
(12, 'Apple MacBook Air', 'Apple MacBook Air 13.6 ', 1, 1359.00, 2, 5, 'images/Apple MacBook Air.jpeg'),
(13, 'MSI Katana 17', 'MSI Katana 17 B12VFK-634XPL 17.3', 1, 2166.00, 2, 5, 'images/MSI Katana 17.jpeg'),
(14, 'Samsung Odyssey Neo G9', 'Samsung Odyssey Neo G9 LS57CG954 Ultrawide VA HDR Curved Gaming Monitor 57', 5, 2918.00, 1, 1, 'images/Samsung Odyssey Neo G9.jpeg'),
(15, 'MSI MEG 342C', 'MSI MEG 342C QD-OLED HDR Curved Monitor 34.18', 5, 1888.00, 1, 1, 'images/MSI MEG 342C.jpeg'),
(16, 'AMD Ryzen 5 9600X 3.9GHz', 'Επεξεργαστής AMD Ryzen™ 9000 Series αρχιτεκτονικής «Zen 5» για υψηλές επιδόσεις σε παιχνίδια και απαιτητικές εφαρμογές. Τοποθετείται σε μητρική με Socket AM5.', 7, 328.00, 31, NULL, 'images/AMD_Ryzen_5_9600X.jpeg'),
(20, 'Total War: Rome II Spartan Edition PC Game', 'Η έκδοση Spartan Edition αποτελεί μια συλλεκτική έκδοση του Total War: Rome II, αφιερωμένη στους αρχαίους έλληνες πολεμιστές που διαμόρφωσαν τον τρόπο πολέμου στην αρχαιότητα, επιδεικνύοντας απαράμιλλη στρατιωτική εξειδίκευση.', 2, 16.00, 5, 26, 'images/Total War Rome 2.jpeg'),
(21, 'Creality3D K1C Αυτόνομος 3D Printer', 'Αυτόνομος 3D εκτυπωτής της εταιρείας Creality3D. Δεν χρειάζεται συναρμολόγηση. Διαθέτει μονό extruder. Πρόκειται για τον συνηθέστερο τύπο 3D εκτυπωτή.', 6, 530.00, 25, NULL, 'images/Creality3D K1C.jpeg'),
(22, 'Grand Theft Auto V', 'Καλωσόρισες στο Λος Σάντος, μπες στις ζωές τριών πολύ διαφορετικών εγκληματιών, του Michael, του Franklin και του Trevor, καθώς ρισκάρουν τα πάντα σε μια σειρά δύσκολων και επικίνδυνων ληστειών που μπορούν να τους αποκαταστήσουν για μια ζωή.', 2, 19.00, 5, 26, 'images/Grand Theft Auto V.jpeg'),
(23, 'Cyberpunk 2077', 'Το Cyberpunk 2077 είναι μια ιστορία δράσης και περιπέτειας ανοιχτού κόσμου που διαδραματίζεται στο Night City, μια μεγαλούπολη που έχει εμμονή με τη δύναμη, τη γοητεία και την τροποποίηση του σώματος. ', 2, 31.00, 5, 26, 'images/Cyberpunk 2077.jpeg'),
(24, 'DOOM Eternal', 'Ζήστε τον απόλυτο συνδυασμό ταχύτητας και δύναμης, καταστρέψτε την κόλαση, σώστε την ανθρωπότητα και ανακαλύψτε το παρελθόν του Slayer στο DOOM Eternal.', 2, 19.00, 5, 26, 'images/DOOM Eternal.jpeg'),
(25, 'Assassin Creed Odyssey', 'Σφυρηλατήστε τον θρύλο σας σε έναν κόσμο που μαστίζεται από πολέμους και κυριαρχείται από θεούς και ανθρώπους.', 2, 28.00, 5, 26, 'images/Assassin Creed Odyssey.jpeg'),
(26, 'Logitech Pro X TKL Ασύρματο Gaming Μηχανικό Πληκτρολόγιο Tenkeyless με RGB φωτισμό ', 'Ένα ασύρματο πληκτρολόγιο για gaming, ιδανικό για πρωταθλήματα, σχεδιασμένο για τα υψηλότερα επίπεδα ανταγωνιστικού παιχνιδιού. Σχεδιασμένο σε συνεργασία με επαγγελματίες παίκτες και κατασκευασμένο για τη νίκη.', 2, 205.00, 6, NULL, 'images/logitech_pro_x_tkl_asyrmato_gaming_michaniko_pliktrologio.jpeg'),
(27, 'Razer Ornata V3 Gaming', 'Γνωρίστε το Razer Ornata V3—ένα χαμηλού προφίλ εργονομικό πληκτρολόγιο Gaming που τροφοδοτείται από το Razer Chroma RGB.', 2, 80.00, 6, NULL, 'images/razer_ornata_v3_gaming_michaniko.jpeg'),
(28, 'Corsair K70 RGB Pro Gaming Μηχανικό Πληκτρολόγιο με Corsair OPX', 'Tο Corsair K70 RGB Pro διατηρεί τα εμβληματικά στοιχεία του βραβευμένου K70, με ανθεκτικό πλαίσιο αλουμινίου, οπτoμηχανικούς διακόπτες CORSAIR OPX για μέγιστη ακρίβεια και απόκριση, οπίσθιο φωτισμό RGB ανά πλήκτρο και τεχνολογία AXON, επαναπροσδιορίζοντας τις επιδόσεις.', 2, 249.00, 6, NULL, 'images/corsair_k70_rgb_pro_gaming_michaniko_pliktrologio.jpeg'),
(29, 'Razer DeathAdder Essential Gaming', 'Για περισσότερο από μια δεκαετία, η σειρά Razer DeathAdder αποτέλεσε το στυλοβάτη της παγκόσμιας esports σκηνής.', 2, 21.00, 6, NULL, 'images/20190111171041_924f1f1e.jpeg'),
(30, 'Logitech G502 Hero RGB Gaming', 'Το G502 HERO διαθέτει έναν προηγμένο οπτικό αισθητήρα για μέγιστη ακρίβεια παρακολούθησης κίνησης, προσαρμοζόμενο φωτισμό RGB, προσαρμοσμένα προφίλ παιχνιδιών, ευαισθησία ρυθμιζόμενη από 100 έως 16.000 DPI και βαρίδια με δυνατότητα αλλαγής θέσης.', 2, 46.00, 6, NULL, 'images/logitech_g502_hero_rgb_gaming_pontiki.jpeg'),
(31, 'Sony PlayStation 5 Slim', 'Το μέγεθος της νέας έκδοσης PS5 έχει μειωθεί περισσότερο από 30% και το βάρος κατά 18% σε σύγκριση με τα προηγούμενα μοντέλα. Επίσης, η νέα κονσόλα διαθέτει 1ΤΒ ωφέλιμου αποθηκευτικού χώρου σε σύγκριση με τα 825GB του προηγούμενου μοντέλου.', 2, 511.00, 9, NULL, 'images/sony_playstation_5_slim.jpeg'),
(32, 'Microsoft Xbox Series X 1TB', 'Το Νέο Xbox Series X έρχεται και είναι πιο γρήγορο και πιο ισχυρό. Με Blu-Ray μονάδα, απολαύστε ανάλυση 4K/8K στα 60 έως 120 FPS, με μειωμένους χρόνους φόρτωσης χάρη στον SSD 1TB που εξασφαλίζουν απρόσκοπτο παιχνίδι και ανοίγουν την πόρτα στην επόμενη γενιά παιχνιδιών.', 2, 528.00, 9, NULL, 'images/microsoft_xbox_series_x_1tb.jpeg'),
(33, 'Anda Seat Phantom 3', 'Η Phantom 3 της Anda Seat, είναι μια εργονομική και στιβαρή καρέκλα, που σχεδιάστηκε για να προσφέρει άνεση και υποστήριξη σε όσους περνούν πολύ χρόνο στη θέση του γραφείου, είτε για παιχνίδια είτε για εργασία. Διαθέτει πολλές ρυθμιζόμενες λειτουργίες, όπως ύψους, κλίσης, μπράτσων, καθώς και ρυθμιζόμενο κάθισμα, για να προσαρμόζετε την ιδανική θέση για σας μπροστά στον υπολογιστή σας.', 2, 248.00, 10, NULL, 'images/anda_seat_phantom_3_karekla_gaming.jpeg'),
(34, 'Corsair T3 Rush Fabric (2023)', 'Η καρέκλα gaming Corsair T3 Rush συνδυάζει σχεδιασμό εμπνευσμένο από τους αγώνες και άνεση, με εξωτερικό μαλακό ύφασμα που αναπνέει, μαξιλάρι λαιμού με επένδυση και οσφυϊκή στήριξη από αφρό μνήμης.  Η νέα καρέκλα gaming της Corsair προσφέρει άνετη και εργονομική εμπειρία καθίσματος κατά τη διάρκεια του gaming. ', 2, 299.00, 10, NULL, 'images/corsair_t3_rush_fabric_2023_yfasmatini_karekla_gaming.jpeg'),
(35, 'Oxford Home GC-3031B Καρέκλα Gaming', 'Καρέκλα gaming της εταιρείας Oxford Home, ιδανική για ανθρώπους που παραμένουν πολλές ώρες μπροστά από τον υπολογιστή τους, είτε για παιχνίδια είτε για εργασία.', 2, 123.00, 10, NULL, 'images/oxford_home_gc_3031b_karekla_gaming.jpeg'),
(36, 'Samsung Galaxy S24 Ultra 5G Dual SIM (12GB/256GB) Titanium Black', 'Αν ψάχνετε για την απόλυτη εμπειρία smartphone με την καλύτερη τεχνολογία κάμερας, βελτιωμένες λειτουργίες και έναν υπερπολυτελή σχεδιασμό, το Samsung Galaxy S24 Ultra είναι η τέλεια επιλογή. Είναι ιδανικό για δυνατούς χρήστες, επαγγελματίες και λάτρεις της τεχνολογίας που θέλουν το καλύτερο.', 3, 1050.00, 12, NULL, 'images/samsung_galaxy_s24_ultra_5g_dual_sim_12gb_256gb.jpeg'),
(37, 'Apple iPhone 16 Pro Max 5G (8GB/256GB) White Titanium', 'Με το iOS 18 μπορείς να δώσεις στα εικονίδια της Αρχικής Οθόνης σου οποιοδήποτε χρώμα. Βρες τις αγαπημένες σου φωτογραφίες πιο γρήγορα στη νέα εφαρμογή Φωτογραφίες. Και πρόσθεσε παιχνιδιάρικα, κινούμενα εφέ σε οποιαδήποτε λέξη, φράση ή emoji στο iMessage.', 3, 1699.00, 12, NULL, 'images/apple_iphone_16_pro_max_5g_8gb_256gb.jpeg'),
(38, 'Xiaomi Redmi Note 13 Pro+ 5G Dual SIM (8GB/256GB) ', 'Το Redmi Note 13 Pro+ ξεχωρίζει με τον πιο κομψό, πιο premium σχεδιασμό του και τα βελτιωμένα χαρακτηριστικά απόδοσης. Προσφέρει ταχύτερη φόρτιση, εξασφαλίζοντας ότι μπορείτε να ενεργοποιηθείτε γρήγορα και να επιστρέψετε στην ημέρα σας με ελάχιστο χρόνο διακοπής.', 3, 329.00, 12, NULL, 'images/xiaomi_redmi_note_13_pro_5g_dual_sim_12gb.jpeg'),
(39, 'Google Pixel 9 Pro 5G (16GB/256GB) Obsidian', 'Το Pixel 9 Pro διαθέτει μπροστινή κάμερα 42MP, μια τεράστια αναβάθμιση σε σχέση με την selfie κάμερα 10,5MP του Pixel 8 Pro. Η συστοιχία της πίσω κάμερας υποστηρίζει επίσης Super Res Zoom και 8K για βίντεο. Έτσι, αν η ποιότητα και τα χαρακτηριστικά της κάμερας είναι η βασική σας προτεραιότητα, το Pixel 9 Pro θα μπορούσε να είναι μια άξια αναβάθμιση.', 3, 1414.00, 12, NULL, 'images/google_pixel_9_pro_5g_16gb_256gb_obsidian.jpeg'),
(40, 'Samsung Smart Τηλεόραση 50\" 4K UHD LED UE50DU7172UXXH HDR (2024)', 'Μέσω του οικοσυστήματος ανοιχτής εφαρμογής του λειτουργικού συστήματος Tizen της Samsung, το Daily+ σάς επιτρέπει να διαχειρίζεστε εύκολα τις καθημερινές σας δραστηριότητες από την άνεση της τηλεόρασής σας. Το Daily+ περιλαμβάνει εφαρμογές και υπηρεσίες όπως το SmartThings και το Workspace.', 4, 394.00, 18, NULL, 'images/samsung_smart_tileorasi.jpeg'),
(41, 'LG Smart Τηλεόραση 43\" 4K UHD LED 43UR78006L HDR (2023)', 'Η τηλεόραση LG 75UR78006LK απευθύνεται σε καταναλωτές που αναζητούν μια μεγάλη τηλεόραση με υψηλή ανάλυση και απόδοση, καθώς και προηγμένες τεχνολογίες εικόνας και ήχου. Η τηλεόραση αυτή διαθέτει μια οθόνη 75 ιντσών με ανάλυση 4K, που παρέχει ζωντανά χρώματα, απόλυτη ευκρίνεια και βαθύ μαύρο, χάρη στην τεχνολογία NanoCell.', 4, 345.00, 18, NULL, 'images/lg_smart_tileorasi_43_4k.jpeg'),
(42, 'Vengeance MSI Edition Gaming Desktop PC', 'Η συγκεκριμένη σύνθεση Desktop PC απευθύνεται σε ατομικούς χρήστες ή gamers που θέλουν έναν ισχυρό υπολογιστή για να παίζουν τα πιο απαιτητικά παιχνίδια και να εκτελούν απαιτητικές εργασίες, όπως επεξεργασία βίντεο και 3D σχεδιασμός. ', 1, 665.00, 1, 3, 'images/vengeance_msi_edition_gaming_desktop_pc.jpeg'),
(43, 'HP Pro 290 G9 Desktop PC', 'Το HP 290 G9 Tower είναι ενα Desktop PC ένας ισχυρός και αξιόπιστος υπολογιστής που προσφέρει εξαιρετική απόδοση για τις καθημερινές εργασίες σας.', 1, 581.00, 1, 1, 'images/hp_pro_tower_290_g9_desktop_pc.jpeg');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `sub_category1`
--

CREATE TABLE `sub_category1` (
  `subcategory1_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `sub_category1`
--

INSERT INTO `sub_category1` (`subcategory1_id`, `category_id`, `name`) VALUES
(1, 1, 'Desktop PC'),
(2, 1, 'Laptops'),
(3, 1, 'Περιφεριακά Laptops'),
(4, 1, 'Ανταλλακτικά Laptop'),
(5, 2, 'video games'),
(6, 2, 'Περιφερειακά Gaming'),
(9, 2, 'Κονσόλες'),
(10, 2, 'Καρέκλες Gaming'),
(11, 2, 'Αξεσουάρ Gaming'),
(12, 3, 'Κινητά Τηλέφωνα'),
(13, 3, 'Θήκες Κινητών'),
(14, 3, 'Φορτιστές Κινητών'),
(15, 3, 'Bluetooth Handsfree'),
(16, 3, 'Προστατευτικά Οθόνης'),
(17, 3, 'Tablets'),
(18, 4, 'Τηλεοράσεις'),
(19, 4, 'Συσκευές Multimedia'),
(20, 4, 'Projectors'),
(21, 4, 'Βάσεις Τηλεοράσεων'),
(22, 4, 'Ηχεία'),
(23, 4, 'Ακουστικά'),
(24, 4, 'Αυτοενισχυόμενα Ηχεία'),
(25, 6, 'Εκτυπωτές'),
(26, 6, '3D Printers'),
(27, 6, 'Αναλώσιμα Εκτυπωτών'),
(28, 7, 'Μνήμες RAM'),
(29, 7, 'SSD Σκληροί Δίσκοι'),
(30, 7, 'Κάρτες Γραφικών'),
(31, 7, 'Επεξεργαστές'),
(32, 7, 'Μητρικές Κάρτες'),
(33, 7, 'Κουτιά Υπολογιστών'),
(34, 7, 'Τροφοδοτικά Υπολογιστή'),
(35, 7, 'Υδρόψυξη'),
(36, 8, 'Γραφική Ύλη'),
(37, 8, 'Εξοπλισμός Γραφείου'),
(38, 8, 'Είδη Αρχειοθέτησης'),
(39, 10, 'Οικιακές Συσκευές'),
(40, 10, 'Έπιπλα'),
(41, 10, 'Κήπος'),
(42, 10, 'Φωτισμός'),
(44, 11, 'Καστάνιες & Καρυδάκια'),
(45, 11, 'Κατσαβίδια Χειρός'),
(46, 11, 'Πένσες & Κόφτες'),
(47, 11, 'Διάφορα Εργαλεία Χειρός');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `sub_category2`
--

CREATE TABLE `sub_category2` (
  `subcategory2_id` int(11) NOT NULL,
  `subcategory1_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `sub_category2`
--

INSERT INTO `sub_category2` (`subcategory2_id`, `subcategory1_id`, `name`) VALUES
(1, 1, 'Mini PC'),
(2, 1, 'All-in-one PC'),
(3, 1, 'Gaming PC'),
(4, 1, 'SERVERS'),
(5, 2, 'Workstation'),
(6, 2, 'Gaming Laptop'),
(7, 2, 'Notebook'),
(8, 2, 'Netbook'),
(9, 2, '2 in 1'),
(10, 3, 'Τσάντες Laptop'),
(11, 3, 'Βάσεις Laptop'),
(12, 3, 'Docking Stations Laptops'),
(13, 3, 'Φορτιστές Laptop'),
(14, 4, 'Μπαταρίες Laptop'),
(15, 4, 'Laptop Skins'),
(16, 4, 'Καρτες PCMCIA'),
(17, 4, 'πληκτρολόγια Laptop'),
(18, 4, 'Ανεμιστηράκια Laptop'),
(19, 4, 'Οθόνες Laptop'),
(20, 4, 'Βύσματα τροφοδοσίας Laptop'),
(21, 4, 'Πλαίσια Laptop'),
(22, 4, 'Διαφορα Αξεσουαρ & ανταλλακτικά Laptops'),
(26, 5, 'gaming');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user',
  `image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`, `image`) VALUES
(12, 'admin', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', 'Admin', ''),
(13, 'user', 'user@gmail.com', '202cb962ac59075b964b07152d234b70', 'Anonymous', '');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Ευρετήρια για πίνακα `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Ευρετήρια για πίνακα `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Ευρετήρια για πίνακα `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Ευρετήρια για πίνακα `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `sub_category1_id` (`subcategory1_id`),
  ADD KEY `sub_category2_id` (`subcategory2_id`);

--
-- Ευρετήρια για πίνακα `sub_category1`
--
ALTER TABLE `sub_category1`
  ADD PRIMARY KEY (`subcategory1_id`),
  ADD KEY `fkcategory` (`category_id`);

--
-- Ευρετήρια για πίνακα `sub_category2`
--
ALTER TABLE `sub_category2`
  ADD PRIMARY KEY (`subcategory2_id`),
  ADD KEY `fk_subcategory2` (`subcategory1_id`);

--
-- Ευρετήρια για πίνακα `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `advertisements`
--
ALTER TABLE `advertisements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT για πίνακα `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT για πίνακα `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT για πίνακα `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT για πίνακα `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT για πίνακα `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT για πίνακα `sub_category1`
--
ALTER TABLE `sub_category1`
  MODIFY `subcategory1_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT για πίνακα `sub_category2`
--
ALTER TABLE `sub_category2`
  MODIFY `subcategory2_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT για πίνακα `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Περιορισμοί για πίνακα `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  ADD CONSTRAINT `products_ibfk_3` FOREIGN KEY (`subcategory1_id`) REFERENCES `sub_category1` (`subcategory1_id`),
  ADD CONSTRAINT `products_ibfk_4` FOREIGN KEY (`subcategory2_id`) REFERENCES `sub_category2` (`subcategory2_id`);

--
-- Περιορισμοί για πίνακα `sub_category1`
--
ALTER TABLE `sub_category1`
  ADD CONSTRAINT `fkcategory` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Περιορισμοί για πίνακα `sub_category2`
--
ALTER TABLE `sub_category2`
  ADD CONSTRAINT `fk_subcategory2` FOREIGN KEY (`subcategory1_id`) REFERENCES `sub_category1` (`subcategory1_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
